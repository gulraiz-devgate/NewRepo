{% snapshot snapshot_fact_order_refund_line_items %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='refund_line_item_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('fact_order_refund_line_items')}}

{% endsnapshot %}


