{% snapshot snapshot_fact_abandoned_checkouts %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='abandoned_checkout_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('fact_abandoned_checkouts')}}

{% endsnapshot %}