{% snapshot snapshot_dim_products %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='product_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('dim_products')}}

{% endsnapshot %}