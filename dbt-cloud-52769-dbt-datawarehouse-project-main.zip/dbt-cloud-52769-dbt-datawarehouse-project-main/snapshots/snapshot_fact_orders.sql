{% snapshot snapshot_fact_orders %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='order_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('fact_orders')}}

{% endsnapshot %}