{% snapshot snapshot_dim_customers %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='customer_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('dim_customers')}}

{% endsnapshot %}