{% snapshot snapshot_fact_order_refunds %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='refund_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('fact_order_refunds')}}

{% endsnapshot %}