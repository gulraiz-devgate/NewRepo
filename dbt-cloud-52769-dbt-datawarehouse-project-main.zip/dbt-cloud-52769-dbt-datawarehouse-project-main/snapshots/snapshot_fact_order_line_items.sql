{% snapshot snapshot_fact_order_line_items %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='line_item_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('fact_order_line_items')}}

{% endsnapshot %}

