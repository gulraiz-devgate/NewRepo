{% snapshot snapshot_dim_stores %}

        {{
            config(
                target_schema= 'snapshots',
                strategy='check',
                unique_key='store_id',
                check_cols='all'
            )
        }}

        Select 
        *
        from 
        {{ ref('dim_stores')}}

{% endsnapshot %}