{{ config(materialized='incremental',sort='customer_id', unique_key='customer_id',on_schema_change='sync_all_columns')
}}	

with parsed as (
 
         select distinct 
         cast(id as bigint) as customer_id
        ,first_name
        ,last_name
        ,email
        ,json_extract_path_text(default_address , 'phone') as phone
        ,json_extract_path_text(default_address, 'address1') as addressline1
        ,json_extract_path_text(default_address, 'address2') as addressline2        
        ,--split_part(json_extract_path_text(default_address, 'city'),' ',1) as city  --extracting first part of city
        json_extract_path_text(default_address, 'city') as city
        ,json_extract_path_text(default_address, 'province') as "state/province"
        ,json_extract_path_text(default_address, 'country') as country 
        ,json_extract_path_text(default_address, 'country_code') as country_code
        ,json_extract_path_text(default_address, 'zip') as zip_code
        ,last_order_name
        ,cast(orders_count as int) as orders_count
        ,cast(total_spent as decimal(10,2)) as total_spent
        ,dateadd(hour,5,accepts_marketing_updated_at) as accepts_marketing_updated_at
        ,dateadd(hour,5,created_at) as created_at
        ,dateadd(hour,5,updated_at) as updated_at
        ,accepts_marketing 
        ,verified_email 
         
      from {{ source('raw','customers') }}
)

 select distinct
 customer_id
,first_name
,last_name
,email
,phone
,addressline1
,addressline2
,city as city_notcleaned
,case
 when city ilike('%Dina%') then 'Dina'
 when city ilike('%Quetta%') then 'Quetta'
 when city ilike('%Karachi%') then 'Karachi'
 when city ilike('%Fsd%') then 'Faisalabad'
 when city ilike('%Rahim Yar Khan%') then 'Rahim Yar Khan'
 when city ilike('%Lakecity%') then 'Lahore'
 when city ilike('%Lahore%') then 'Lahore'
 when city ilike('%Loher%') then 'Lahore'
 when city ilike('Wah%') then 'Wah'
 when city ilike('%Rabwah%') then 'Chenab Nagar'
 when city ilike('%Rwp%') then 'Rawalpindi'
 when city ilike('%Shaheed Benazir%') then 'Nawabshah'
 when city ilike('%Islamabad%') then 'Islamabad'
 when city ilike('%Suk%') then 'Sukkur'
 when city ilike('%Swat%') then 'Swat'
 when city ilike('%Hub Chowki%') then 'Hub'
 when city ilike('%Sargodha%') then 'Sargodha'
 when city ilike('%Shahpur%') then 'Shahpur'
 when city ilike('%Turbat%') then 'Turbat'
 when city ilike('%Jand%') then 'Jand'
 when city ilike('%Chitral%') then 'Chitral'
 when city ilike('%Dadyal%') then 'Dadyal'
 when city ilike('%Nankana%') then 'Nankana Sahib'
 when city ilike('%Sat%lite%town%') then 'Rawalpindi'
 when city ilike('%Peshawar%') then 'Peshawar'
 when city ilike('%Bahawalpur%') then 'Bahawalpur'
 when city ilike('%Sial more%') then 'Sargodha'
 when city ilike('%Dg%Khan%' ) then 'Dera Ghazi Khan'
 when city ilike('%D.g%Khan%' ) then 'Dera Ghazi Khan'
 when city ilike('%D g%Khan%' ) then 'Dera Ghazi Khan'
 when city ilike('Di%Khan%' ) then 'Dera Ismail Khan'
 when city ilike('%D.i%Khan%' ) then 'Dera Ismail Khan'
 when city ilike('%D i%Khan%' ) then 'Dera Ismail Khan'
 when city ilike('%Lasbela%') then 'Lasbela'
 when city ilike('%Haveli Bahadur Shah%') then 'Jhang'
 when city ilike('%Pir Jo Goth%') then 'Khairpur'
 when city ilike('%Moro' ) then 'Moro'
 when city ilike('%Kotli%' ) then 'Kotli'
 when city ilike('%Saidu%' ) then 'Saidu Sharif'
 when city ilike('%Tariq%road%' ) then 'Karachi'
 when city ilike('%Okara%') then 'Okara'
 when city ilike('%Mandi%Bah%' ) then 'Mandi Bahauddin'
 when city ilike('%Hayatabad%' ) then 'Peshawar'
 when city ilike('%Jalal%Pur Bhattian%' ) then 'Jalalpur Bhattian'
 when city ilike('%Tarbe%la%' ) then 'Tarbela'
 when city ilike('%Tariq%roa%' ) then 'Karachi'
 when city ilike('%Gujrat%' ) then 'Gujrat'
 when city ilike('%Rahimyar%' ) then 'Rahim Yar Khan'
 when city ilike('%Rawalakot%' ) then 'Rawalakot'
 when city ilike('%Nowshe%ra%' ) then 'Nowshera'
 when city ilike('%Ch%niot%' ) then 'Chiniot'
 when city ilike('%Tariq%roa%' ) then 'Karachi'
 when city ilike('%P%r%gon City%' ) then 'Lahore'
 when city ilike('%Dina%') then 'Dina'
 when city ilike('%Surgicare Hospital%') then 'Rawalpindi'
 when city ilike('%Saidu%' ) then 'Saidu Sharif'
 when city ilike('%Dir upper%' ) then 'Upper Dir'
 when city ilike('%Sehwan%' ) then 'Sehwan Sharif'
 when city ilike('%Rasul Pur Colony%') then 'Sahiwal'
 when city ilike('%Drosh%') then 'Chitral'
 when city ilike('%Ahm_d Pur East%') then 'Ahmedpur Sharqia'
 when city ilike('%Mirpur K%') then 'Mirpur Khas'
 when city ilike('%Mirpur A%') then 'Mirpur Azad Kashmir'
 when city ilike('%Select City Faisalabad%') then 'Faisalabad'
 when city ilike('Select City') then ' '
 when city ilike('%Jhang%') then 'Jhang'
 when city ilike('%Garha More%') then 'Mailsi'
 when city ilike('Khi') then 'Karachi'
 when city ilike('Pakistan') then  ' '
 when city ilike('Balochistan') then ' '
 when city ilike('United Arab Emirates') then ' '
 when city ilike('Sindh') then ' '
 when city ilike('Same') then ' '
 when city ilike('Azad Kashmir') then ' '
 when city ilike('Mirpur') then ' '
 when city ilike('Bharakahu%') then 'Islamabad'
 when city ilike('Pindi') then 'Rawalpindi'
 when city ilike('%Muzaffarabad Azad%') then 'Muzaffarabad'
 when city ilike('%Yazman%') then 'Yazman Mandi'
 when city ilike('Mirpur') then 'Mirpur Azad Kashmir'
 else city end as city
,"state/province"
,country
,country_code
,zip_code
,last_order_name
,orders_count
,total_spent
,accepts_marketing_updated_at 
,created_at
,updated_at
,accepts_marketing 
,verified_email
 from parsed


{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where updated_at > (select max(updated_at) from {{ this }})

{% endif %}


