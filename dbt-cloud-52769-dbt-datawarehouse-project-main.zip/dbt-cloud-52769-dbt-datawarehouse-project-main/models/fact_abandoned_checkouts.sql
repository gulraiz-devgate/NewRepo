{{ config(materialized='incremental',sort='abandoned_checkout_id', unique_key='abandoned_checkout_id',on_schema_change='sync_all_columns')
}}	


with recursive numbers(n) as
( select '0'::int  as n
union all
select n + 1
from numbers n
where n.n <=100
),

 joined as(
 select
 id as abandoned_checkout_id
 ,"name"
 ,_sdc_shop_id as store_id
 ,cast(json_extract_path_text(customer,'id') as bigint) as customer_id
 ,cart_token
 ,cast(subtotal_price as numeric) as subtotal_price
 ,cast(total_line_items_price as numeric)  as total_line_items_price
 ,cast(total_discounts as numeric) as total_discounts
 ,taxes_included
 ,cast(total_tax as numeric) as total_tax
 ,cast(total_price as numeric) as total_price
 ,gateway as payment_method
 ,dateadd(hour,5,closed_at) as closed_at
 ,dateadd(hour,5,completed_at) as completed_at
 ,dateadd(hour,5,created_at) as created_at
 ,dateadd(hour,5,updated_at) as updated_at
 ,json_extract_array_element_text(
            line_items , 
            numbers.n::int, 
            true
            ) as item from
{{ source('raw','abandoned_checkouts') }}   as ac

 cross join numbers
    --only generate the number of records in the cross join that corresponds
    --to the number of items in the order
    where numbers.n <
        json_array_length(ac.line_items, true)
),

parsed as (
    --before returning the results, actually pull the relevant keys out of the
    --nested objects to present the data as a SQL-native table.
    --make sure to add types for all non-VARCHAR fields.
    select 
     cast(abandoned_checkout_id as bigint) as abandoned_checkout_id
    ,"name"
    ,cast(store_id as bigint) as store_id
    ,cast(customer_id as bigint) as customer_id
    ,cast(json_extract_path_text(item,'product_id') as bigint) as product_id 
    ,json_extract_path_text(item,'sku') as sku
    ,cart_token
    ,cast(json_extract_path_text(item,'quantity') as int) as quantity
    ,cast(subtotal_price as decimal(10,2)) as subtotal_price
    ,cast(total_line_items_price as decimal(10,2)) as total_line_items_price
    ,cast(total_discounts as decimal(6,2)) as total_discounts
    ,taxes_included
    ,cast(total_tax as decimal(6,2)) as total_tax
    ,cast(total_price as decimal(10,2)) as total_price
    ,payment_method
    ,closed_at
    ,completed_at
    ,created_at
    ,updated_at

    from joined

)

select * from parsed
 
 

{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where updated_at > (select max(updated_at) from {{ this }})

{% endif %}

