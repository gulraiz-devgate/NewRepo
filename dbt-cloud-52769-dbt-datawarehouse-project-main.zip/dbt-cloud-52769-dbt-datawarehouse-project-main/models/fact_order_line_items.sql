{{ config(materialized='incremental',sort='product_id', unique_key='line_item_id',on_schema_change='sync_all_columns')
}}	

with recursive numbers(n) as
( select '0'::int  as n
union all
select n + 1
from numbers n
where n.n <=100
),
joined as (
    select 
        orders.id, 
        orders._sdc_shop_id as store_id,
        orders.created_at ,
        orders.updated_at ,
        orders.processed_at,
        json_extract_path_text(customer,'id') as customer_id,
        json_array_length(line_items , true) as number_of_items,
        json_extract_array_element_text(
            line_items , 
            numbers.n::int, 
            true
            ) as item
    from {{ source('raw','orders') }}
    as orders
    cross join numbers
    --only generate the number of records in the cross join that corresponds
    --to the number of items in the order
    where numbers.n <
        json_array_length(orders.line_items, true) 

),

parsed as (
    --before returning the results, actually pull the relevant keys out of the
    --nested objects to present the data as a SQL-native table.
    --make sure to add types for all non-VARCHAR fields.
    select 
         cast(json_extract_path_text(item, 'id') as bigint)  as line_item_id
        ,cast(id as bigint) as order_id
        ,cast(store_id as bigint)
        ,cast(customer_id as bigint)
        ,case when json_extract_path_text(item, 'product_id')=' ' then null else 
         cast(json_extract_path_text(item, 'product_id') as bigint) end as product_id 
        --,json_extract_path_text(item, 'sku') as sku
        ,json_extract_path_text(item, 'product_exists') as product_exists 
        --,json_extract_path_text(item, 'vendor') as vendor
        ,cast(json_extract_path_text(item, 'price') as decimal(10,2)) as price
        ,cast(json_extract_path_text(item, 'quantity') as int) as quantity
        ,json_extract_path_text(item, 'fulfillment_status') as fulfillment_status
        ,dateadd(hour,5,processed_at) as processed_at
        ,dateadd(hour,5,created_at) as created_at
        ,dateadd(hour,5,updated_at) as updated_at
      
    from joined
)

select * from parsed 


{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where updated_at > (select max(updated_at) from {{ this }})

{% endif %}

