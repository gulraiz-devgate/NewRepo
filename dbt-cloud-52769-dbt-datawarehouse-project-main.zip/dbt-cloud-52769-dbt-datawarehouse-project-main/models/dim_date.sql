{{ config(materialized='incremental',sort='datekey', unique_key='datekey',on_schema_change='sync_all_columns')
}}	

with recursive numbers(n) as
( select '01-01-2020'::date as n
union all
select n + 1
from numbers n
where n.n <=220
)
,dates as 
(
select  
to_char(n,'yyyymmdd') as datekey
,n as "date"
,date_part(year,n)  as "year" 
,date_part(month,n) as "month no."
,date_part(quarter,n) as "quarter"
,date_part(week,n) as "week no."
,to_char(n,'Day') as "dayofweek"
,to_char(n,'Mon') as "month_name"
from numbers
)
,dates_final as(
select 
 datekey
,"date"
,cast("year" as smallint)
,cast("quarter" as smallint)
,cast("month no." as smallint)
,month_name
,cast("week no." as smallint)
,dayofweek
from dates
where "date"<= trunc(getdate()))

select * from dates_final

{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where "date" >  (select max("date") from {{ this }})

{% endif %}