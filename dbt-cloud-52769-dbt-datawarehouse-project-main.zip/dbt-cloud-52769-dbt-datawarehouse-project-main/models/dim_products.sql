{{ config(materialized='incremental',sort='product_id', unique_key='product_id',on_schema_change='sync_all_columns')
}}	


with recursive numbers(n) as
( select '0'::int  as n
union all
select n + 1
from numbers n
where n.n <=100
),

joined as (
select distinct
	id as product_id
	,title as product_name
	,product_type
	,json_extract_path_text(image , 'src',true) as image
	,tags
	,status
	,vendor
	,json_array_length(variants , true) as number_of_items
        ,json_extract_array_element_text(
            variants  , 
            numbers.n::int, 
            true
            ) as variants
  ,created_at 
	,published_at
	,updated_at        
            from {{ source('raw','products') }} as p
            cross join numbers 
             where numbers.n <
        json_array_length(p.variants , true)	
),

parsed as (
	select distinct 
	 cast(product_id as bigint)
	,json_extract_path_text(variants , 'sku',true) as sku
	,product_name 
	,product_type
	,image 
	,tags
	,status
	,json_extract_path_text(variants , 'barcode') as barcode 
	,cast(json_extract_path_text(variants , 'price') as decimal(10,2)) as discounted_price
	,cast(json_extract_path_text(variants , 'compare_at_price') as decimal(10,2)) as full_price
	,cast(json_extract_path_text(variants , 'inventory_quantity') as int) as inventory_quantity 
	,json_extract_path_text(variants , 'taxable') as taxable
	,json_extract_path_text(variants , 'requires_shipping') as requires_shipping
	,dateadd(hour,5,created_at) as created_at
	,dateadd(hour,5,published_at) as published_at
	,dateadd(hour,5,updated_at) as updated_at
	,vendor
	 from joined 	
),	

 inventory as (
   select distinct
    sku
   ,cost
    from (
     select sku
           ,cast(cost as decimal(10,2)) as cost
           ,rank()over(partition by sku order by updated_at desc),updated_at 
            from {{ source('raw','inventory_items') }}) as A
   where rank=1
	  
)
    select distinct  
      A.product_id
     ,A.sku
     ,A.product_name 
     ,A.product_type
     ,A.image
     ,A.tags 
     ,A.status 
     ,A.barcode 
     ,A.discounted_price 
     ,A.full_price 
     ,A.inventory_quantity 
     ,A.taxable 
     ,B.cost
     ,A.requires_shipping 
     ,A.created_at 
     ,A.published_at 
     ,A.updated_at
     ,A.vendor 
     from 
     parsed as A
     left join 
     inventory as B
     on
     A.sku=B.sku
      
     

{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where updated_at > (select max(updated_at) from {{ this }})

{% endif %}
