{{ config(materialized='incremental',sort='order_id', unique_key='order_id',on_schema_change='sync_all_columns')
}}	

with orders as( select distinct 
 cast(id as bigint) as order_id
,cast(_sdc_shop_id as bigint) as store_id
,cast(json_extract_path_text(customer,'id') as bigint) as customer_id 
,confirmed as order_confirmation
,json_extract_path_text(client_details,'user_agent') as device_type
,financial_status
,cancel_reason 
,fulfillment_status
,gateway as payment_method
,order_number
,currency 
,referring_site 
,cast(subtotal_price as numeric) as subtotal
,cast(total_discounts as numeric) 
,case when total_line_items_price <2000 then 200 else 0 end as shipping
,cast(total_line_items_price as numeric) 
,taxes_included 
,cast(total_tax as numeric) 
,cast(total_price as numeric) as total
,processing_method 
,dateadd(hour,5,cancelled_at) as cancelled_at
,dateadd(hour,5,created_at) as created_at
,dateadd(hour,5,processed_at) as processed_at
,dateadd(hour,5,updated_at) as updated_at
 from {{ source('raw','orders') }}
)
select * from orders


{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where updated_at > (select max(updated_at) from {{ this }})

{% endif %}
