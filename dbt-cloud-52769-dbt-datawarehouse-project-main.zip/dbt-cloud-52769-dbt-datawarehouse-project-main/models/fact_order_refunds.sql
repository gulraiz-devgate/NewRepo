{{ config(materialized='incremental',sort='refund_id', unique_key='refund_id',on_schema_change='sync_all_columns')
}}	

with recursive numbers(n) as
( select '0'::int  as n
union all
select n + 1
from numbers n
where n.n <=100
),
joined as (
    select
        cast(or2.id as bigint) as refund_id,
        cast(or2.order_id as bigint) , 
        cast(or2."_sdc_shop_id" as bigint) as store_id,
        or2.created_at  ,
        or2.processed_at  ,
        cast(json_array_length(refund_line_items , true) as bigint) as number_of_items,
        json_extract_array_element_text(
            refund_line_items  , 
            numbers.n::int, 
            true
            ) as item
    from {{ source('raw','order_refunds') }} as or2
    cross join numbers
    --only generate the number of records in the cross join that corresponds
    --to the number of items in the order
    where numbers.n <
        json_array_length(or2.refund_line_items , true)
),

customer_orders as
(
    select 
     cast(json_extract_path_text(customer,'id') as bigint) as customer_id
    ,cast(id as bigint) as order_id
    from {{ source('raw','orders') }}
),
parsed as (
    --before returning the results, actually pull the relevant keys out of the
    --nested objects to present the data as a SQL-native table.
    --make sure to add types for all non-VARCHAR fields.
    select  
         A.refund_id
        ,A.order_id
        ,A.store_id
        ,B.customer_id
        ,SUM(cast(json_extract_path_text(item,'quantity') as int)) as quantity
        ,SUM(cast(json_extract_path_text(item, 'subtotal') as decimal(10,2))) as total 
        ,dateadd(hour,5,A.created_at) as created_at
        ,cast(processed_at as datetime) as processed_at   
    from joined as A
    left join 
    customer_orders as B
    on 
    A.order_id=B.order_id
    group by A.refund_id ,A.order_id ,A.store_id ,B.customer_id 
    ,dateadd(hour,5,A.created_at)
    ,cast(processed_at as datetime)
)

select * from parsed

{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where created_at > (select max(created_at) from {{ this }})

{% endif %}