{{ config(materialized='incremental',sort='refund_line_item_id', unique_key='refund_line_item_id',on_schema_change='sync_all_columns')
}}	

with recursive numbers(n) as
( select '0'::int  as n
union all
select n + 1
from numbers n
where n.n <=100
),
joined as (
    select 
        or2.order_id , 
        or2.created_at  ,
        or2.processed_at  ,
        restock,
        or2._sdc_shop_id as store_id,
        json_array_length(refund_line_items , true) as number_of_items,
        json_extract_array_element_text(
            refund_line_items  , 
            numbers.n::int, 
            true
            ) as item,
        json_extract_array_element_text(
            order_adjustments , 
            numbers.n::int, 
            true
            ) as order_adjustments
    from {{ source('raw','order_refunds') }} as or2
    cross join numbers
    --only generate the number of records in the cross join that corresponds
    --to the number of items in the order
    where numbers.n <
        json_array_length(or2.refund_line_items , true)
),

order_customers as 
(    
    select 
     id as order_id
    ,json_extract_path_text(customer,'id') as customer_id
    from {{ source('raw','orders') }}
),

parsed as (
    --before returning the results, actually pull the relevant keys out of the
    --nested objects to present the data as a SQL-native table.
    --make sure to add types for all non-VARCHAR fields.
    select 
        cast(json_extract_path_text(item, 'id') as bigint) as refund_line_item_id,
        cast(A.order_id as bigint) as order_id,
        cast(B.customer_id as bigint) as customer_id,
        cast(store_id as bigint),
        cast(json_extract_path_text(item, 'line_item_id') as bigint) as line_item_id ,
        case when json_extract_path_text(json_extract_path_text(item, 'line_item'),'product_id')=' '
        then NULL else cast(json_extract_path_text(json_extract_path_text(item, 'line_item'),'product_id') as bigint)
        end as product_id ,
        cast(json_extract_path_text(json_extract_path_text(item, 'line_item'),'quantity') as numeric) as quantity,
        cast(json_extract_path_text(json_extract_path_text(item, 'line_item'),'price') as numeric) as price,
        restock,
        --cast(json_extract_path_text(order_adjustments, 'amount') as smallint) as adjustment,
        json_extract_path_text(item, 'restock_type') as restock_type,
        dateadd(hour,5,created_at) as created_at,
        cast(processed_at AS datetime) as processed_at
         
      
    from joined A
    inner join 
    order_customers B
    on
    A.order_id = B.order_id
)

select * from parsed

{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where created_at > (select max(created_at) from {{ this }})

{% endif %}


