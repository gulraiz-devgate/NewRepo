{{ config(materialized='incremental', unique_key='store_id',on_schema_change='sync_all_columns')
}}

	select distinct
	   cast(_sdc_shop_id as bigint) as store_id,
    _sdc_shop_name as store_name,
    _sdc_shop_myshopify_domain as store_domain

	

	from {{ source('raw','products') }}


	{% if is_incremental() %}

  -- this filter will only be applied on an incremental run
  where store_name NOT IN  (select store_name from {{ this }})

{% endif %}

	



	